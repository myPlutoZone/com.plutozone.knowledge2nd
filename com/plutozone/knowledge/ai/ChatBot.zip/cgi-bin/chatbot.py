#-*- coding: utf-8 -*-
import sys
import io
import cgi
from botengine import make_reply

sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8')

# 입력 양식의 글자 추출하기 --- (※1)
form = cgi.FieldStorage()

# 메인 처리 --- (※2)
def main():
    m = form.getvalue("m", default="")
    if   m == "" : show_form()
    elif m == "say" : api_say()

# 사용자의 입력에 응답하기 --- (※3)
def api_say():
    print("Content-Type: text/plain; charset=utf-8")
    print("")
    txt = form.getvalue("txt", default="")
    if txt == "": return
    res = make_reply(txt)
    print(res)

# 입력 양식 출력하기 --- (※4)
def show_form():
    print("Content-Type: text/html; charset=utf-8")
    print("")
    print("""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
        <style>
            h1   {background-color: #ffe0e0; }
            div  {padding: 10px; }
            span {border-radius: 5px; background-color: #ffe0e0; padding:8px;}
            .bot {text-align: left; }
            .usr {text-align: right; }
        </style>
    </head>
    <body>
        <h1 style="text-align: center"> 챗봇 for 고객센터 at 이커머스 7차</h1>
        <div class='usr' style="text-align: center">
            <input id="txt" size="50" onKeyPress="if (event.keyCode == 13) say();">
            <button onclick="say()">문의 하기</button>
        </div>
        <div id="chat"></div>
        <script>
        var url = "./chatbot.py";
        function say() {
          var txt = $('#txt').val();
          $.get(url, {"m":"say","txt":txt},
            function(res) {
              var html = "<div class='usr'> 고객의 문의: <span>" + esc(txt) +
                "</span></div><div class='bot'> 고객센터의 답변: <span>" + 
                esc(res) + "</span></div>";
              $('#chat').html(html + $('#chat').html());
              $('#txt').val('').focus();
            });
        }
        function esc(s) {
            return s.replace('&', '&amp;').replace('<','&lt;')
                    .replace('>', '&gt;');
        }
        </script>
    </body>
    </html>
    """)

main()
